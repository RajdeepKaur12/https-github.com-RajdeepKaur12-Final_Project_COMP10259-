// Keep the navigation bar fixed through jQuery
$(document).ready(function() {
    var header = $('.header');
    $(window).scroll(function() {
        if ($(window).scrollTop() > 0) {
            header.addClass('fixed');
        } else {
            header.removeClass('fixed');
        }
    });

    // Make the lightbox images and videos displayed as a slide show
    $('.Gallery').click(function() {
        var slideshow = $('.slideshow');
        slideshow.empty();
        
        // Add your slideshow logic here
    });

    // Close the slideshow by clicking anywhere outside
    $('.slideshow').click(function(e) {
        if ($(e.target).hasClass('slideshow')) {
            $(this).empty();
        }
    });
});
